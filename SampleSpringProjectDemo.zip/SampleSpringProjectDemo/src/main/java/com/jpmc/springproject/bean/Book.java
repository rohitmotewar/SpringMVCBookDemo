package com.jpmc.springproject.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


@Entity
public class Book 
{
	@NotEmpty(message="ISBN Cannot be empty")
	@Id
	private String isbn; 
	@NotEmpty(message="Title Cannot be empty")  //bean Validator (JSR) validator "OR" below
	//@NotNull(message="Title Cannot be empty") // Add java x Dependency
	private String title;
	@NotEmpty(message="Author Cannot be empty")
	private String author;
	private double price;
	

	
	@Min(value=1)
	@Max(value=200)
	private long stock;
	private String genre;
	
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public long getStock() {
		return stock;
	}
	public void setStock(long stock) {
		this.stock = stock;
	}
	public Book(String isbn, String title, String author, double price, long stock,String genre) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.price = price;
		this.stock = stock;
		this.genre=genre;
		
	}
	public Book() {
		super();
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", author=" + author + ", price=" + price + ", stock="
				+ stock + ", genre=" + genre + "]";
	}
	
	
	
	
	
}
