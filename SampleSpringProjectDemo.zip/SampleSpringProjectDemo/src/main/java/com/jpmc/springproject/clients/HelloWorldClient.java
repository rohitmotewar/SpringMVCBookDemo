package com.jpmc.springproject.clients;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jpmc.springproject.bean.Customer;
import com.jpmc.springproject.dao.classes.CustomerDaoJPA;
import com.jpmc.springproject.services.interfaces.CustomerServiceI;

public class HelloWorldClient {
	private static EntityManagerFactory emf;
	private static EntityManager em;
	
	static{
		
		 emf=Persistence.createEntityManagerFactory("SpringDemo");
		
		
	}
	
	public static void main(String[] args) {
		
		
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
		
		Customer customerBean=(Customer) ctx.getBean("customerBean");
		
		customerBean.setEmail("sam@gmail.com");
		customerBean.setName("Sam");
		
		System.out.println("Hello World--"+customerBean);
		
		System.out.println(customerBean.getEmail());
		
/*		Customer customerBean2=(Customer) ctx.getBean("customerBean");
		System.out.println(customerBean2);*/
		
		
		
		CustomerServiceI serviceBean=(CustomerServiceI) ctx.getBean("customerServiceBean");
		serviceBean.SetCustomer(customerBean);  //
		
		serviceBean.printCustomerDetails();	
		
		
	
		
		
		
	}

}
