package com.jpmc.springproject.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jpmc.springproject.bean.Book;
import com.jpmc.springproject.services.interfaces.BookServiceI;

@Controller
public class BookController 
{
	@Autowired // Not required to have setter it will wire it automatically..
	private BookServiceI bookservice;
	
	
	
	//@ResponseBody   // If you use ResponseBody it will execute method body return stmt like print Hello this is Spring Demo
	@RequestMapping("/hello")
	public String sayHello()
	{
		//return "Hello-This is Spring Demo";
		return "login";   //If you dont use @Responsebody it will executes...index.jsp..look for the page
		
		//Refer Spring-Servlet , where mapping is done through property with suffix and prefix.
	}

	@RequestMapping("/addbook")
	public String addBook(Model model)
	{	
		Book book=new Book();
		book.setPrice(10.0); //Setting Default value
		book.setStock(10);
		model.addAttribute("book", book);	
		return "addbook";
	}
	

	@RequestMapping(method=RequestMethod.POST, value="addbook")
	public String addBookMessage(@Valid @ModelAttribute("book")Book book,BindingResult result)
	{
		if(result.hasErrors())
		{
			return "addbook";
		}
		System.out.println(book);
		//return "Book Added";
		
		bookservice.addBook(book);
		return "redirect:/viewstore";
	}
	
	@RequestMapping(method=RequestMethod.GET, value="viewstore")
	public String viewStore(Model model, HttpServletRequest request)
	{
		List<String> generList = bookservice.getGenre(); // to get genre List
		System.out.println(generList);
		model.addAttribute("generList",generList);
		
		
		List<Book> bookList=bookservice.getAllBooks();
		//System.out.println(bookList);
		
		model.addAttribute("bookList", bookList);
		
		HttpSession session=request.getSession();
		session.setAttribute("bookList", bookList);
		
		return "viewstore"; //delete from View all book page "viewstore.jsp"
	}
	
	/*@ResponseBody*/
	@RequestMapping(method=RequestMethod.GET, value="deletebook")
	public String deleteBook(@RequestParam("isbn") String isbn) //returning isbn after deleting the book using Reqparam method
	{
		bookservice.deleteBook(isbn);
		//return "Book Deleted with ISBN:-"+isbn;
		
		return "redirect:/viewstore";
	}
	
	//using path variable
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="deletebook1/isbn/{isbn}")
	public String deleteBook2(@PathVariable("isbn") String isbn) //returning isbn after deleting the book using Reqparam method
	{
		return "Book Deleted with ISBN:-"+isbn;
	}
	
	@RequestMapping("/updateform")
	public String updateBookForm(HttpServletRequest request,  @RequestParam("isbn") String isbn, Model model)
	{
		System.out.println("ISBN"+isbn);
		
		
		List<Book> bookList= (List<Book>) request.getSession().getAttribute("bookList");
				
		System.out.println(bookList);	
		
		Book bookupdated=search(bookList,isbn);
		
		model.addAttribute("bookupdated", bookupdated);
		
		
		return "updateform";
		
	}

	private Book search(List<Book> bookList, String isbn) 
	{
	
		for(Book book:bookList)
		{
			if(book.getIsbn().equals(isbn)) return book;
				
		}
		return null;
	}

	@RequestMapping(method=RequestMethod.POST, value="updatebook")
	public String updateBook(@ModelAttribute("bookupdated") Book updatedBook)
	{
		System.out.println("Updated Book:-"+updatedBook);
		
		bookservice.updateBook(updatedBook.getIsbn(), updatedBook.getPrice(), updatedBook.getStock());
		return "redirect:/viewstore";
		
	}
	
	@RequestMapping(value="cancel",method=RequestMethod.POST )
	public String cancel()
	{
		return "redirect:/viewstore";
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="getbooks")
	public String getBooks(Model model, HttpServletRequest request,@RequestParam("gener") String gener){
		List<String> generList = bookservice.getGenre();
		System.out.println(generList);
		model.addAttribute("generList",generList);	
		System.out.println("im in getBooks" +gener );
			List<Book> bookList = bookservice.getAllBooks(gener);
			System.out.println(" Get books  : " + bookList);
			model.addAttribute("bookList",bookList);		
		return "viewstore";
	}
	

}
