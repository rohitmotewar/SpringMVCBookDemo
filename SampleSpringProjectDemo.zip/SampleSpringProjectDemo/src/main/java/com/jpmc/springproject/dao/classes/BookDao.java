package com.jpmc.springproject.dao.classes;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.jpmc.springproject.bean.Book;
import com.jpmc.springproject.dao.interfaces.BookDaoI;

@Repository //It handles data thats why it is Repository you can user @Service or @Reporsitory
public class BookDao implements BookDaoI 
{
	@PersistenceContext
	private EntityManager em;
	

	@Override
	public List<Book> getAllbooks() {
	
		return em.createQuery("from Book").getResultList();
				
	}


	@Override
	public void deleteBook(String isbn) {
		
		/*return em.createQuery("from Book where isbn=:isbn");*/
		
		Book book=em.find(Book.class, isbn);
		em.remove(book);
		
	}


	@Override
	public boolean addBook(Book book) {
		
	//	em.getTransaction().begin(); 
		em.persist(book); 			
//		em.getTransaction().commit();	
		
		return true;
		
	}


	@Override
	public boolean updateBook(String isbn, double price, long stock) {
		Book updatedBook =em.find(Book.class, isbn);
		updatedBook.setPrice(price);
		updatedBook.setStock(stock);
		return true;	
	}


	@Override
	public List<String> getGenre() {
		Query q =em.createQuery("select distinct b.genre from Book b");
		System.out.println(q.getFirstResult());
		return q.getResultList();
		
	}


	@Override
	public List<Book> getAllBooks(String genre) {
		
		if(!genre.equalsIgnoreCase("all"))
		{
			Query query = em.createQuery("from Book b where b.genre=:genre");
			query.setParameter("genre", genre);
		return query.getResultList();
		
		}
		return em.createQuery("from Book b").getResultList();
	}
	

}
