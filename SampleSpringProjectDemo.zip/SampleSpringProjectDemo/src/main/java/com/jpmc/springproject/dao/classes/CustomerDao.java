package com.jpmc.springproject.dao.classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.jpmc.springproject.dao.interfaces.CustomerDaoI;

public class CustomerDao implements CustomerDaoI
{

	private String driverClass;
	private String dbUrl;
	private String user;
	private String password;
	private Connection conn;
	
	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getDriverClass() {
		return driverClass;
	}



	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}



	public String getDbUrl() {
		return dbUrl;
	}



	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}



	public  void configure() {
		
		System.out.println("Configuring the DB");
		
		System.out.println("DB URL:"+dbUrl);
		System.out.println("Driver Class-"+driverClass);
		
		//Connecting to Db
		
		try{
			Class.forName(driverClass);
			conn=DriverManager.getConnection(dbUrl,user,password);
			if(conn!=null)
			{
				System.out.println("Connection Successful with JDBC");
				
			}
		}	catch(ClassNotFoundException | SQLException e)
			{
				e.printStackTrace();
			}
		
		
		
		
	}
	
//	public static void main(String[] args) {
//		CustomerDao db=new CustomerDao();
//		db.configure();
//		
//		
//	}

	
}
