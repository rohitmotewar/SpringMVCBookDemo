package com.jpmc.springproject.dao.classes;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.jpmc.springproject.dao.interfaces.CustomerDaoI;

public class CustomerDaoJPA implements CustomerDaoI
{
	private static EntityManager em;
	private static EntityManagerFactory emf;
	
	
	


	
	
	@Override
	public void configure() {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("SpringDemo");
		EntityManager em=emf.createEntityManager();
		if(emf!=null)
		{
		System.out.println("Connection Successfull with JPA");
		}
		
		
	}
	
	
	
	
}
