package com.jpmc.springproject.dao.interfaces;

import java.util.List;

import com.jpmc.springproject.bean.Book;

public interface BookDaoI 
{
	public List<Book>  getAllbooks();
	
	public void deleteBook(String isbn);
	
	public boolean addBook(Book book);
	
	public boolean updateBook(String isbn,double price,long stock);
	
	public List<String> getGenre();
	public List<Book> getAllBooks(String genre);

}
