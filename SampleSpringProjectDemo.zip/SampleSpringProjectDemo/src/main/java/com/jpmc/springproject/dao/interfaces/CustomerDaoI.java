package com.jpmc.springproject.dao.interfaces;

public interface CustomerDaoI 
{
	
	public void configure();
	
	

}
