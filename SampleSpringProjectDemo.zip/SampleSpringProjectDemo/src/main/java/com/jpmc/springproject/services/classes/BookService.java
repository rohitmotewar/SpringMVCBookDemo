package com.jpmc.springproject.services.classes;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.springproject.bean.Book;
import com.jpmc.springproject.dao.interfaces.BookDaoI;
import com.jpmc.springproject.services.interfaces.BookServiceI;

@Component   //you can @Service also 
public class BookService implements BookServiceI 
{
	@Autowired
	private BookDaoI bookDao;
	
	/*public BookDaoI getBookDao() {
		return bookDao;
	}


	public void setBookDao(BookDaoI bookDao) {
		this.bookDao = bookDao;
	}
*/

	@Override
	public List<Book> getAllBooks() {
		return bookDao.getAllbooks();
	
	}


	@Transactional
	@Override
	public void deleteBook(String isbn) {
		bookDao.deleteBook(isbn);
				
	}

	@Transactional
	@Override
	public boolean addBook(Book book) {
		// TODO Auto-generated method stub
		bookDao.addBook(book);
		return true;
	}

	@Transactional
	@Override
	public boolean updateBook(String isbn, double price, long stock) {
	
		bookDao.updateBook(isbn, price, stock);
		return true;
		
		
	}


	@Override
	public List<String> getGenre() {
		
		return bookDao.getGenre();
	}
	
	@Override
	public List<Book> getAllBooks(String genre) {
		// TODO Auto-generated method stub
		return bookDao.getAllBooks(genre);
	}
	
	
}
