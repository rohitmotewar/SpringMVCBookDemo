package com.jpmc.springproject.services.classes;

import com.jpmc.springproject.bean.Customer;
import com.jpmc.springproject.dao.classes.CustomerDao;
import com.jpmc.springproject.dao.interfaces.CustomerDaoI;
import com.jpmc.springproject.services.interfaces.CustomerServiceI;

public class CustomerService implements CustomerServiceI 
{
	private Customer customer;
	private CustomerDaoI customerDao;
	
	
	public CustomerDaoI getCustomerDao() {
		return customerDao;
	}



	public void setCustomerDao(CustomerDaoI customerDao) {
		System.out.println("Setter Called for Dao");
		this.customerDao = customerDao;
	}



	public Customer getCustomer() {
		return customer;
	}


	
	public void printCustomerDetails() 
	{
		
		System.out.println(customer);
		
		customerDao.configure();
		
		
	}


	public void SetCustomer(Customer customer) {
		// TODO Auto-generated method stub
		this.customer=customer;
		
	}

	

}
