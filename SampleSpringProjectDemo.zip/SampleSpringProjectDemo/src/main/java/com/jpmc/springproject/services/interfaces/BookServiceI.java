package com.jpmc.springproject.services.interfaces;

import java.util.List;

import com.jpmc.springproject.bean.Book;

public interface BookServiceI 
{

	public List<Book> getAllBooks();
	public  void deleteBook(String isbn);
	public boolean addBook(Book book);
	
	public boolean updateBook(String isbn,double price,long stock);
	public List<String> getGenre();
	public List<Book> getAllBooks(String genre);
	
	
	
}
