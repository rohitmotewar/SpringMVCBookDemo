package com.jpmc.springproject.services.interfaces;

import com.jpmc.springproject.bean.Customer;

public interface CustomerServiceI 
{
	public Customer getCustomer();
	public void SetCustomer(Customer customer);
	
	public void printCustomerDetails();
	
	

}
